using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile);
{
namespace Cars.wwwroot.Welcome_Files
{
    public class managingwebsiteModel : PageModel
    {
        public void OnGet()
        {
            public class IndexModel : PageModel
        {

            private readonly IWebHostEnvironment _env;

            public IndexModel(IWebHostEnvironment env)
            {
                _env = env;
            }

            [BindProperty]
            public Welcome welcomeNote { get; set; }


            Now we need to write the content of OnGet method.

  public IActionResult OnGet()
            {
                DateTime dd = DateTime.Now;
                string date = dd.ToString("dd/MM/yyyy");
                Console.WriteLine(date);
                welcomeNote = new Welcome();
                welcomeNote.DateUpdate = date;



                for (int i = 1; i < 4; i++)
                {
                    string WelcomeFile = "Welcome_para" + i + ".txt";
                    var FileLocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile);

                    {
                        using (StreamReader sr = new StreamReader(FileLocation))
                        {
                            String line = sr.ReadToEnd();


                            if (i == 1)
                            {
                                welcomeNote.Message1 = line;
                                Console.WriteLine("The current text before update is : " + welcomeNote.Message1);
                            }
                            else if (i == 2)
                            {
                                welcomeNote.Message2 = line;
                                Console.WriteLine("The current text before update is : " + welcomeNote.Message2);
                            }
                            else
                            {
                                welcomeNote.Message3 = line;
                                Console.WriteLine("The current text before update is : " + welcomeNote.Message3);
                            }

                        }
                    }
                catch (IOException e)
                    {
                        Console.WriteLine("The file could not be read:");
                        Console.WriteLine(e.Message);
                    }
                }
                public IActionResult OnPost()
                {
                    
                    for (int i = 1; i < 4; i++)
                    {
                        // Set a variable to the Documents path.
                        string WelcomeFile = "Welcome_para" + i + ".txt";
                        var FileLocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile);

                        using (StreamWriter sw = new StreamWriter(FileLocation))
                        {
                            if (i == 1)
                                sw.WriteAsync(welcomeNote.Message1);

                            if (i == 2)
                                sw.WriteAsync(welcomeNote.Message2);

                            if (i == 3)
                                sw.WriteAsync(welcomeNote.Message3);
                        }
                    }
                    return RedirectToPage("/Home");
                }

            }
        }
    }
}