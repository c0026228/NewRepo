﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Cars.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cars",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Carbrand = table.Column<string>(nullable: true),
                    Carmodel = table.Column<string>(nullable: true),
                    Yearregistered = table.Column<string>(nullable: true),
                    EngineSize = table.Column<string>(nullable: true),
                    Carcolour = table.Column<string>(nullable: true),
                    Regplate = table.Column<string>(nullable: true),
                    Price = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cars", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cars");
        }
    }
}
