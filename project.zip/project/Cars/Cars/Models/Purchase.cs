﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Cars.Models
{
    public class Purchase
    {
            public int Id { get; set; }

            [Display(Name = "Car ID")]
            public int CarID { get; set; }
            [Display(Name = "Client ID")]
            public int ClientID { get; set; }
            [Display(Name = "SaleStaff ID")]
            public string SaleStaffID { get; set; }
            [Display(Name = "Date of Purchase")]
            public string DateofPurchase { get; set; }
            [Display(Name = "Payment Details")]
            public string PaymentDetails { get; set; }
            [Display(Name = "Time of Purchase")]
            public string TimeofPurchase { get; set; }
    }
}
