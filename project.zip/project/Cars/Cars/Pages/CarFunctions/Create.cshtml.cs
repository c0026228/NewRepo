﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Cars.Data;
using Cars.Models;

namespace Cars.Pages.Shared.CarFunctions
{
    public class CreateModel : PageModel
    {
        private readonly Cars.Data.CarsContext _context;

        public CreateModel(Cars.Data.CarsContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public CarTypes CarTypes { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Cars.Add(CarTypes);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
