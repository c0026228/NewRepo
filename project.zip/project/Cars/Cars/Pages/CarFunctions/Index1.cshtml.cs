
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Cars.Data;
using Cars.Models;

namespace Cars.Pages.Shared.CarFunctions
{
    public class Index1Model : PageModel
    {
        public CarTypes CarFunctions { get; set; }
        public void OnGet()
        {
        }
    }
}
