using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;
using Cars.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace Cars.Pages.Shared.CarFunctions
{
    public class UpdateModel : PageModel
    {

        [BindProperty]
        public CarTypes Cars { get; set; }

        public IActionResult OnPost()
        {
            string DbConnection = @"CarsContext-1621e4f2-0e8f-4243-97ad-862c006d8f4a";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("Car Brand : " + Cars.Carbrand);
            Console.WriteLine("Car Model : " + Cars.Carmodel);
            Console.WriteLine("Car Brand : " + Cars.Carbrand);
            Console.WriteLine("Year Registered : " + Cars.Yearregistered);
            Console.WriteLine("Engine Size : " + Cars.EngineSize);
            Console.WriteLine("Car Colour : " + Cars.Carcolour);
            Console.WriteLine("Reg Plate : " + Cars.Regplate);
            Console.WriteLine("Price : " + Cars.Price);


            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Cars SET Car Brand = @Carbrand, Car Model = @Carmodel, Car Brand = @Carbrand, Year Registered = @Yearregistered, Engine Size = @EngineSize, Car Colour = @Carcolour, Reg Plate = @Regplate, Price = @Price, WHERE Id = @ID";

                command.Parameters.AddWithValue("@Carbrand", Cars.Carbrand);
                command.Parameters.AddWithValue("@Carmodel", Cars.Carmodel);
                command.Parameters.AddWithValue("@Carbrand", Cars.Carbrand);
                command.Parameters.AddWithValue("@Yearregistered", Cars.Yearregistered);
                command.Parameters.AddWithValue("@Enginesize", Cars.EngineSize);
                command.Parameters.AddWithValue("@Carcolour", Cars.Carcolour);
                command.Parameters.AddWithValue ("@Regplate", Cars.Regplate);
                command.Parameters.AddWithValue("@Price", Cars.Price);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/Home");
        }
    }
}

