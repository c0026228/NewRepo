using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Cars.Pages.ClientsEnquiry
{
    public class ClientsequiryModel : PageModel
    {

        [BindProperty]

        public Client.Models.Clients Client { get; set; }

        public void OnGet()
        {
        }
               public List<SelectListItem> Nationality = new List<SelectListItem>
             {
               new SelectListItem { Text = "British", Value = "British"},
               new SelectListItem { Text = "European", Value = "European"},
               new SelectListItem { Text = "African", Value = "African", Selected = true },
               new SelectListItem { Text = "American", Value = "American"},
               new SelectListItem { Text = "Asian", Value = "Asian"},
               new SelectListItem { Text = "Australian", Value = "Australian"},
             };

        public IActionResult OnPost()

        {
            return RedirectToPage("/Index");
        }
    }
}


