﻿using System;

namespace Cars.Login
{
    internal class DatabaseConnect
    {
        internal string Databasestring()
        {
            throw new NotImplementedException();
        }
    }
}