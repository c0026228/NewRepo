﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_Session.Pages.DatabaseConnection
{
    public class DatabaseConnect
    {
        public string DatabaseString ()
        {
            string DbString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:CarsContext-1621e4f2-0e8f-4243-97ad-862c006d8f4a";
            return DbString;
        }

        internal string Databasestring()
        {
            throw new NotImplementedException();
        }
    }
}
