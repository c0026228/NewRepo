using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Client.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;


namespace Cars.Login
{
    public class LoginModel : PageModel
    {
        public new Clients User { get; set; }
        public string Message { get; set; }

        public string SessionsID;

        public void ONGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            DatabaseConnect dbstring = DatabaseConnect(); //Creates an object from a class
            string DbConeection = dbstring.Databasestring();
            Console.WriteLine(DbConnection);
            SqlConnnection conn = new SqlConnnection(DbConeection);
            conn.Open();

            Console.WriteLine(User.EmailAddress);
            Console.WriteLine(User.Password);


            using (SqlCommand command = new SqlCommand()) 
            {
                command.Connection = conn;
                command.CommandText = @"SELECT FirstName, EmailAddress, UserRole FROM UserTable WHERE EmailAddress = @EmailAddress AND UserPassword = @Pwd";


                command.Parameters.AddWithValue("@EmailAddress", User.EmailAddress);
                command.Parameters.AddWithValue("@Pwd", User.Password);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    User.FirstName = reader.GerString(0);
                    User.EmailAddress = reader.Getstring(1);
                    User.Role = reader.Getstring(2);
                }

            }

            if (!string.IsNullOrEmpty(User.FirstName))
            {
                SessionsID = HttpContext.Session.Id;
                HttpContext.Session.SetString("sessionID", SessionsID);
                HttpContext.Session.SetString("EmailAddress", User.EmailAddress);
                HttpContext.Session.SetString("Fname", User.FirstName);

                if (User.Role == "User")
                {
                    return RedirectToPage("/UserPages/UserIndex");
                }
                else
                {
                    return RedirectToPage("/AdminPages/AdminIndex");
                }
            }
            else
            {
                Message = "Invalid Username and Password";
                return Page();
            }
        }

        private DatabaseConnect DatabaseConnect()
        {
            throw new NotImplementedException();
        }
    }
}
