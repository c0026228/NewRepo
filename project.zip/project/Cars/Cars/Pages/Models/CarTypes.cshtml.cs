using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Cars.Models
{
    public class CarTypes : PageModel
    {

        public int Id { get; set; }

        [Display(Name = "Car brand")]
        public string Carbrand { get; set; }
        [Display(Name = "Car model")]
        public string Carmodel { get; set; }
        [Display(Name = "Year registered")]
        public string Yearregistered { get; set; }
        [Display(Name = "Engine Size")]
        public string EngineSize { get; set; }
        [Display(Name = "Car Colour")]
        public string Carcolour { get; set; }
        [Display(Name = "Reg Plate")]
        public string Regplate { get; set; }
        [Display(Name = "Price")]
        public string Price { get; set; }
    }
}

