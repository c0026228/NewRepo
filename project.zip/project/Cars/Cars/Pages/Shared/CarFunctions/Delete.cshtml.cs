﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Cars.Data;
using Cars.Models;
using Microsoft.Data.SqlClient;

namespace Cars.Pages.Shared.CarFunctions
{
    public class DeleteModel : PageModel
    {
        private readonly Cars.Data.CarsContext _context;

        public DeleteModel(Cars.Data.CarsContext context)
        {
            _context = context;
        }

        [BindProperty]
        public CarTypes CarTypes { get; set; }

        public IActionResult OnPost()
        {
            string DbConnection = @"CarsContext-1621e4f2-0e8f-4243-97ad-862c006d8f4a";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("Car Brand : " + CarTypes.Carbrand);
            Console.WriteLine("Car Model : " + CarTypes.Carmodel);
            Console.WriteLine("Car Brand : " + CarTypes.Carbrand);
            Console.WriteLine("Year Registered : " + CarTypes.Yearregistered);
            Console.WriteLine("Engine Size : " + CarTypes.EngineSize);
            Console.WriteLine("Car Colour : " + CarTypes.Carcolour);
            Console.WriteLine("Reg Plate : " + CarTypes.Regplate);
            Console.WriteLine("Price : " + CarTypes.Price);


            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Cars SET Car Brand = @Carbrand, Car Model = @Carmodel, Car Brand = @Carbrand, Year Registered = @Yearregistered, Engine Size = @EngineSize, Car Colour = @Carcolour, Reg Plate = @Regplate, Price = @Price, WHERE Id = @CarID";

                command.Parameters.AddWithValue("@Carbrand", CarTypes.Carbrand);
                command.Parameters.AddWithValue("@Carmodel", CarTypes.Carmodel);
                command.Parameters.AddWithValue("@Carbrand", CarTypes.Carbrand);
                command.Parameters.AddWithValue("@Yearregistered", CarTypes.Yearregistered);
                command.Parameters.AddWithValue("@Enginesize", CarTypes.EngineSize);
                command.Parameters.AddWithValue("@Carcolour", CarTypes.Carcolour);
                command.Parameters.AddWithValue("@Regplate", CarTypes.Regplate);
                command.Parameters.AddWithValue("@Price", CarTypes.Price);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/Home");
        }
    }
}
        