﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Cars.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Cars.Data;


namespace Cars.Pages.Shared.CarFunctions
{
    public class IndexModel : PageModel
    {
        private const string V = @"Data Source=( Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarsContext-1621e4f2-0e8f-4243-97ad-862c006d8f4a;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        private readonly Cars.Data.CarsContext _context;

        public IndexModel(Cars.Data.CarsContext context)
        {
            _context = context;
        }

        public List<CarTypes> CarTypes { get;set; }

        public async Task OnGetAsync()
        {
            CarTypes = await _context.Cars.ToListAsync();
        }
        
            public IActionResult OnPost()
            {
            var CarsContext = V;
            return RedirectToPage("/Index");
        }

    }
}

