using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cars.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace Cars.Pages.Shared.CarFunctions
{
    public class ViewModel : PageModel
    {
        private const string V = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarsContext-1621e4f2-0e8f-4243-97ad-862c006d8f4a;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public void OnGet()
        {
            SqlConnection conn = new SqlConnection();
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM Cars";

                SqlDataReader reader = command.ExecuteReader();
                List<CarTypes> CarTypes = new List<CarTypes>();
                while (reader.Read())
                {
                    CarTypes record = new CarTypes();
                    record.Id = reader.GetInt32(0);
                    record.Carbrand = reader.GetString(1);
                    record.Carmodel = reader.GetString(2);
                    record.Yearregistered = reader.GetString(3);
                    record.EngineSize = reader.GetString(4);
                    record.Carcolour = reader.GetString(5);
                    record.Regplate = reader.GetString(6);
                    record.Price = reader.GetString(7);

                    CarTypes.Add(record);
                }
                reader.Close();
            }
        }
    }
}
