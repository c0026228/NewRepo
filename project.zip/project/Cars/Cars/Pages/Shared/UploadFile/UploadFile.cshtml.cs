using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace Cars.Pages.Shared.UploadFile
{
    public readonly IWebHostEnvironment _env;

    [BindProperty]
    public IFormFile SaleStaffFile { get; set; }

    public UploadFileModel(IWebHostEnvironment env)
    {
        this._env = env;
    }

    public IActionResult OnPost()
    {
        var FileToUpload = Path.Combine(_env.WebRootPath, "Files", SaleStaffFile.FileName);
        Console.WriteLine("File Name : " + FileToUpload);

        using (var FStream = new FileStream(FileToUpload, FileMode.Create))
        {
            SaleStaffFile.CopyTo(FStream);
        }

        return RedirectToPage("/Home");
    }
}
