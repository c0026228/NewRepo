﻿using System;

namespace Cars.Login
{
    internal class SqlConnection
    {
        private readonly string dbConnection;

        public SqlConnection(string dbConnection)
        {
            this.dbConnection = dbConnection;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}