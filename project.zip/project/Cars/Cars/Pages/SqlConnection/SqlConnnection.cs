﻿using System;

namespace Cars.Login
{
    internal class SqlConnnection
    {
        private readonly string dbConnection;

        public SqlConnnection(string dbConnection)
        {
            this.dbConnection = dbConnection;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}