﻿using System;

namespace Cars.Login
{
    internal class SqlConnection
    {
        private readonly string DbConnection;

        public SqlConnection()
        {
        }

        public SqlConnection(string dbConnection)
        {
            this.DbConnection = dbConnection;
        }

        public SqlConnection Connection { get; internal set; }
        public string CommandText { get; internal set; }
        public object Parameters { get; internal set; }

        internal void Open()
        {
            throw new NotImplementedException();
        }

        internal object ExecuteReader()
        {
            throw new NotImplementedException();
        }
    }
}