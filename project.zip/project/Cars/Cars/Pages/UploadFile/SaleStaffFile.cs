﻿using System;
using System.IO;

namespace Cars.Pages.Shared.UploadFile
{
    internal class SSFile
    {
        internal static void CopyTo(FileStream fStream)
        {
            throw new NotImplementedException();
        }
    }
}