using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cars.Pages.UploadFile
{
    public class UploadFileModel : PageModel
    {
        public readonly IWebHostEnvironment _env;

        public UploadFileModel(IWebHostEnvironment env)
        {
            _env = env;
        }
        


        [BindProperty]
        public IFormFile SSFile { get; set; }

        public IActionResult OnPost()
        {
            var FileToUpload = Path.Combine(_env.WebRootPath, "Files", SSFile.FileName);//this variable consists of file path
            Console.WriteLine("File Name : " + FileToUpload);

            using (var FStream = new FileStream(FileToUpload, FileMode.Create))
            {
                SSFile.CopyTo(FStream);//copy the file into FStream variable
            }

            return RedirectToPage("/Home");
        }


        public void OnGet()
        {
        }
    }
}
