﻿namespace Cars.Pages.Shared.UploadFile
{
    internal class _env
    {
    }
}