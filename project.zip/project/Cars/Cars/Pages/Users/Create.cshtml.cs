using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Login_Session.Models;
using Login_Session.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Login_Session.Pages.Users 
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public User Client { get; set; }

        public List<string> URole { get; set; } = new List<string> { "User", "Admin" }; //creates a list called Urole which collects info about the user and admin
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            DatabaseConnect dbstring = new DatabaseConnect(); 
            string DbConnection = dbstring.DatabaseString(); 
            Console.WriteLine(DbConnection);
            var conn = new SqlConnection();
            conn.Open();
            //making a connection between the database and the website

            Console.WriteLine(Client.FirstName);
            Console.WriteLine(Client.UserName);
            Console.WriteLine(Client.Password);
            Console.WriteLine(Client.Role); //asks user for the information about themself what is needed

            using (SqlCommand command = new SqlCommand()) //instructs the command local variables
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO UserTable (FirstName, UserName, UserPassword, UserRole) VALUES (@FName, @UName, @Pwd, @Role)";
                //what the program will be outputting
                command.Parameters.AddWithValue("@FName", Client.FirstName);
                command.Parameters.AddWithValue("@UName", Client.UserName);
                command.Parameters.AddWithValue("@Pwd", Client.Password);
                command.Parameters.AddWithValue("@Role", Client.Role);
                command.ExecuteNonQuery();
            }

            return RedirectToPage("/Home"); //linking back to the Homepage on the website
        }
    }
}
