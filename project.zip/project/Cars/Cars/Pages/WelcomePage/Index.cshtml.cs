using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Cars.Models;

namespace Cars.Pages.WelcomePage
{
    public class IndexModel : PageModel
    {
        private readonly IWebHostEnvironment _env; //this function provides information about the webhosting environment an application is running in

        public IndexModel (IWebHostEnvironment env) //env is a parameter
        {
            _env = env;
        }

        [BindProperty]
        public Welcome_notes welcomeNote { get; set; }

        public IActionResult OnGet()
        {
            DateTime dd = DateTime.Now;//finding todays date
            string date = dd.ToString("dd/mm/yyyy HH:MM"); // this is how we get the date 
            Console.WriteLine(date); //outputting the date
            welcomeNote = new Welcome_notes();
            welcomeNote.DateUpdate = date; //adding a function the shows the newest date when the notes was last edited

            for (int i = 1; i < 4; i++) // three f
            {
                string WelcomeFile = "Welcome_para" + i + ".txt";
                var FileLocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile); //the location of the file
                try
                {
                    using (StreamReader sr = new StreamReader(FileLocation)) //opens the .txt files
                    {
                        string line = sr.ReadToEnd();
                        Console.WriteLine(line);

                        if (i==1)
                        {
                            welcomeNote.Message1 = line;
                            Console.WriteLine("The current text before update is : " + welcomeNote.Message1);
                        }
                        else if (i==2)
                        {
                            welcomeNote.Message2 = line;
                            Console.WriteLine("The current text before update is : " + welcomeNote.Message2);
                        }
                        else
                        {
                            welcomeNote.Message3 = line;
                            Console.WriteLine("The current text before update is : " + welcomeNote.Message3);
                        }
                    }
                }
                catch (IOException e)
                {
                    Console.WriteLine("The file could not be read"); //can not locate the file
                    Console.WriteLine(e.Message);
                }
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            string Filenames = ""; //storing the name of the files e.g. "welcomepage0101"

            var Filelocation = Path.Combine(_env.WebRootPath);//WebRootPath gets the path from wwwroot folder
            for (int i=1; i <4; i++)
            {
                string WelcomeFiles = "Welcome_para" + i + "txt"; //storing text
                Filelocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFiles);// "welcome Files" is the folder name and welcome files is the txt files

                using (StreamWriter sw = new StreamWriter(Filelocation))
                {
                    if (i == 1)
                        sw.WriteAsync(welcomeNote.Message1); 
                    Filenames += WelcomeFiles + ",";
                    
                    if (i == 2)
                        sw.WriteAsync(welcomeNote.Message2);
                    Filenames += WelcomeFiles + ",";

                    if (i == 3)
                        sw.WriteAsync(welcomeNote.Message3);
                    Filenames += WelcomeFiles + ",";
                    // displaying what order the files should be listed in
                }
            }

            Console.WriteLine("Date : " + welcomeNote.DateUpdate); // asks for the date of the welcome note beign updated
            Console.WriteLine("User : " + welcomeNote.User); //asks who the user is
            Console.WriteLine("File name : " + Filenames); //asks for the file names
            Console.WriteLine("Paths : " + Filelocation); //asks for the file location
            //asking for the data of the list above

            string DbConnection = @"Data Source=(LocalDB)\D:\University\Year 1\Semester 1\Database and web\assignment\DB and web group project\project\Cars\Cars\Pages\WelcomePage\"; //location of the connection
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();
            //connecting to the database

            using (SqlCommand command = new SqlCommand()) //This is used so that it can instruct the code underneath what to do.
            {
                command.Connection = conn;
                command.CommandText = "INSERT INTO WelcomeNote (Date, UserName, FileName, Directory) VALUES (@DateUpdate, @User, @FName, @Fpath)";

                command.Parameters.AddWithValue("@DateUpdate", welcomeNote.DateUpdate);
                command.Parameters.AddWithValue("@User", welcomeNote.User);
                command.Parameters.AddWithValue("@FName", Filenames);
                command.Parameters.AddWithValue("@Fpath", Filelocation);
                //all the data needed
                command.ExecuteNonQuery();

            }


            return RedirectToPage("/Home"); //sends the user back to the homepage
        }
     
    }

   
}
