﻿CREATE TABLE [dbo].[Cars] (
    [Id]             INT            IDENTITY (1, 1) NOT NULL,
    [Carbrand]       NVARCHAR (MAX) NULL,
    [Carmodel]       NVARCHAR (MAX) NULL,
    [Yearregistered] NVARCHAR (MAX) NULL,
    [EngineSize]     NVARCHAR (MAX) NULL,
    [Carcolour]      NVARCHAR (MAX) NULL,
    [Regplate]       NVARCHAR (MAX) NULL,
    [Price]          NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_Cars] PRIMARY KEY CLUSTERED ([Id] ASC)
);

